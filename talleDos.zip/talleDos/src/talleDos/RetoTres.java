package talleDos;

import java.util.Scanner;

public class RetoTres {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean ejecutar = true;

        while (ejecutar) {
            try {
                System.out.println("\n--- Calculadora Aplicada ---");
                
                // 1. Entrada de datos con validación implícita (nextDouble)
                System.out.print("Ingresa el primer número: ");
                double n1 = sc.nextDouble();

                System.out.print("Ingresa el segundo número: ");
                double n2 = sc.nextDouble();

                // 2. Selección de operación
                System.out.print("Elige la operación (+, -, *, /): ");
                char op = sc.next().charAt(0);

                // 3. Lógica con validación de división por cero
                switch (op) {
                    case '+':
                        System.out.println("Resultado: " + (n1 + n2));
                        break;
                    case '-':
                        System.out.println("Resultado: " + (n1 - n2));
                        break;
                    case '*':
                        System.out.println("Resultado: " + (n1 * n2));
                        break;
                    case '/':
                        if (n2 != 0) {
                            System.out.println("Resultado: " + (n1 / n2));
                        } else {
                            System.out.println("Error: No se puede dividir por cero.");
                        }
                        break;
                    default:
                        System.out.println("Operación no válida.");
                }

            } catch (Exception e) {
                System.out.println("Error: Debes ingresar números válidos.");
                sc.next(); // Limpia el error del scanner para no entrar en bucle
            }

            // 4. Opción de salida
            System.out.print("\n¿Deseas realizar otra operación? (s/n): ");
            char respuesta = sc.next().toLowerCase().charAt(0);
            if (respuesta != 's') {
                ejecutar = false;
                System.out.println("Cerrando calculadora...");
            }
        }
        sc.close();
    }
}