package talleDos;

import java.util.Scanner;

public class RetoDos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingrese el número límite: ");
        // Validación básica para asegurar que se ingrese un número
        if (sc.hasNextInt()) {
            int limite = sc.nextInt();
            int sumaPares = 0;
            int contador = 0;

            // Bucle while para recorrer desde 0 hasta el límite
            while (contador <= limite) {
                if (contador % 2 == 0) { // Verifica si el número es par
                    sumaPares += contador;
                }
                contador++;
            }

            System.out.println("La suma de los números pares hasta " + limite + " es: " + sumaPares);
        } else {
            System.out.println("Error: Por favor, ingrese un número entero válido.");
        }
        
        sc.close();
    }
}