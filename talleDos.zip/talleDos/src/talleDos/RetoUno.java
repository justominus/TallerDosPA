package talleDos;

public class RetoUno {
    public static void main(String[] args) {
        
        // --- 1. DETERMINAR EL MAYOR DE TRES VALORES ---
        // Valores enteros predefinidos
        int num1 = 45;
        int num2 = 82;
        int num3 = 31;

        System.out.println("--- Comparación de Números ---");
        
        if (num1 >= num2 && num1 >= num3) {
            System.out.println("El número mayor es: " + num1);
        } else if (num2 >= num1 && num2 >= num3) {
            System.out.println("El número mayor es: " + num2);
        } else {
            System.out.println("El número mayor es: " + num3);
        }

        System.out.println(); // Salto de línea para orden

        // --- 2. OPERADOR TERNARIO (APROBACIÓN) ---
        // Nota fija del estudiante
        double notaFinal = 6.5; 
        
        // Estructura: (condición) ? valor_si_verdadero : valor_si_falso
        String resultado = (notaFinal >= 7.0) ? "Aprobado" : "Reprobado";

        System.out.println("--- Estado Académico ---");
        System.out.println("Nota obtenida: " + notaFinal);
        System.out.println("El estudiante está: " + resultado);
    }
}